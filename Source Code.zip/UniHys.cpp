#include "QuickHys.h"
#include <math.h>
#include <iostream>
#include <elementAPI.h>
#include <OPS_Globals.h>
#include <algorithm>
#include <string>

// OpenSees Material Registration
void* OPS_QuickHys() {
    if (OPS_GetNumRemainingInputArgs() < 24) {
        opserr << "WARNING: insufficient arguments: "
            << "uniaxialMaterial QuickHys tag "
            << "f1p d1p f2p d2p f3p d3p f4p d4p "
            << "f1n d1n f2n d2n f3n d3n f4n d4n "
            << "beta lambda_pre_peak lambda_post_peak lambda_re lambda_un "
            << "unload_fact trans_fact \n";
        return nullptr;
    }
    int tag;
    int numData = 1;
    if (OPS_GetIntInput(&numData, &tag) != 0) {
        opserr << "ERROR: invalid material tag for QuickHys.\n";
        return nullptr;
    }
    double data[23];
    numData = 23;
    if (OPS_GetDoubleInput(&numData, data) != 0) {
        opserr << "ERROR: invalid material parameters for QuickHys.\n";
        return nullptr;
    }
    return new QuickHys(tag,
        data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7],
        data[8], data[9], data[10], data[11], data[12], data[13], data[14], data[15],
        data[16], data[17], data[18], data[19], data[20],
        data[21], data[22]);
}

// Constructor
QuickHys::QuickHys(int tag, double f1p, double d1p, double f2p, double d2p, double f3p, double d3p, double f4p, double d4p,
    double f1n, double d1n, double f2n, double d2n, double f3n, double d3n, double f4n, double d4n,
    double beta, double lambda_pre_peak, double lambda_post_peak, double lambda_re, double lambda_un,
    double unload_fact_new, double trans_fact_new)
    : UniaxialMaterial(tag, 0), f1p_initial(f1p), d1p(d1p), f2p_initial(f2p), d2p(d2p), f3p_initial(f3p), d3p(d3p), f4p_initial(f4p), d4p(d4p),
    f1n_initial(f1n), d1n(d1n), f2n_initial(f2n), d2n(d2n), f3n_initial(f3n), d3n(d3n), f4n_initial(f4n), d4n(d4n),
    beta(beta), lambda_pre_peak(lambda_pre_peak), lambda_post_peak(lambda_post_peak), lambda_re(lambda_re), lambda_un(lambda_un),
    unload_fact(unload_fact_new), trans_fact(trans_fact_new) {
    // Input validation for backbone points
    if (d1p <= 0 || d1p >= d2p || d2p >= d3p || d3p >= d4p) {
        opserr << "ERROR: Positive backbone displacements must be increasing and positive in QuickHys material tag " << tag << "\n";
    }
    if (d1n >= 0 || d1n <= d2n || d2n <= d3n || d3n <= d4n) {
        opserr << "ERROR: Negative backbone displacements must be decreasing and negative in QuickHys material tag " << tag << "\n";
    }
    // Warnings for zero-length segments
    if (d2p == d1p || d3p == d2p || d4p == d3p) {
        opserr << "WARNING: Zero-length segment in positive backbone for QuickHys material tag " << tag << "\n";
    }
    if (d2n == d1n || d3n == d2n || d4n == d3n) {
        opserr << "WARNING: Zero-length segment in negative backbone for QuickHys material tag " << tag << "\n";
    }
    // Additional validation for parameters
    if (beta < 0.0 || beta > 1.0) {
        opserr << "WARNING: beta should be between 0 and 1 in QuickHys material tag " << tag << "\n";
        beta = (beta < 0.0) ? 0.0 : 1.0;
    }
    if (lambda_pre_peak < 0.0 || lambda_post_peak < 0.0 || lambda_re < 0.0 || lambda_un < 0.0) {
        opserr << "WARNING: lambda parameters should be non-negative in QuickHys material tag " << tag << "\n";
    }
    if (unload_fact < 0.0 || unload_fact > 1.0) {
        opserr << "WARNING: unload_fact should be between 0 and 1 in QuickHys material tag " << tag << "\n";
        unload_fact = (unload_fact < 0.0) ? 0.0 : 1.0;
    }
    if (trans_fact < 0.0 || trans_fact > 1.0) {
        opserr << "WARNING: trans_fact should be between 0 and 1 in QuickHys material tag " << tag << "\n";
        trans_fact = (trans_fact < 0.0) ? 0.0 : 1.0;
    }
    // Calculate Monotonic Energy Capacity
    energyU = 0.5 * (d1p * f1p + (d2p - d1p) * (f2p + f1p) + (d3p - d2p) * (f3p + f2p) + (d4p - d3p) * (f4p + f3p) +
        fabs(d1n * f1n) + fabs((d2n - d1n) * (f2n + f1n)) + fabs((d3n - d2n) * (f3n + f2n)) + fabs((d4n - d3n) * (f4n + f3n)));
    if (energyU <= 0) {
        opserr << "ERROR: energyU must be positive in QuickHys material tag " << this->getTag() << "\n";
        energyU = 1e-10; // Avoid division by zero
    }

    this->revertToStart();
}

// Destructor
QuickHys::~QuickHys() {}

// Precompute envelope slopes
void QuickHys::setEnvelope() {
    E1p = f1p / d1p;
    E2p = (d2p > d1p) ? (f2p - f1p) / (d2p - d1p) : 0.0;
    E3p = (d3p > d2p) ? (f3p - f2p) / (d3p - d2p) : 0.0;
    E4p = (d4p > d3p) ? (f4p - f3p) / (d4p - d3p) : 0.0;
    E1n = f1n / d1n;
    E2n = (d2n < d1n) ? (f2n - f1n) / (d2n - d1n) : 0.0;
    E3n = (d3n < d2n) ? (f3n - f2n) / (d3n - d2n) : 0.0;
    E4n = (d4n < d3n) ? (f4n - f3n) / (d4n - d3n) : 0.0;
}

// Set trial strain
int QuickHys::setTrialStrain(double strain, double strainRate) {
    Tdisp = strain;
    double Ddisp = Tdisp - Cdisp;
    if (fabs(Ddisp) < 1e-16) {
        Tfs = Cfs;
        Tks = Cks;
        return 0;
    }
    TdMax = CdMax;
    TdMin = CdMin;
    TdPu = CdPu;
    TdNu = CdNu;
    TloadIndicator = CloadIndicator;
    TcycleCount = CcycleCount;
    TlastLoadIndicator = ClastLoadIndicator;
    Tlast_half_cycle_amplitude = Clast_half_cycle_amplitude;
    Tlast_reversal = Clast_reversal;
    Tprev_reversal = Cprev_reversal;
    Tdelta_rev = Cdelta_rev;
    TDA_max = CDA_max;
    TDcomp = CDcomp;
    TDcomp_last = CDcomp_last;
    TpreCapstrFactor = CpreCapstrFactor;
    TpostCapstrFactor = CpostCapstrFactor;
    // --- Cycle Counting and Damage Update ---
    int prevLoadIndicator = CloadIndicator;
    int newLoadIndicator = (Ddisp > 0.0) ? 1 : 2;
    bool isReversal = (prevLoadIndicator != 0 && newLoadIndicator != prevLoadIndicator);
    if (isReversal) {
        TcycleCount++;
        Tprev_reversal = Tlast_reversal;
        Tlast_reversal = Cdisp;
        Tlast_half_cycle_amplitude = fabs(Tlast_reversal - Tprev_reversal);
        Tdelta_rev = Tlast_half_cycle_amplitude;
        double Deff_pos = CdMax;
        double Deff_neg = -CdMin;
        
        // === PARK-ANG DAMAGE INDEX ===
        double DA_pos = (Deff_pos > 0.0) ? Deff_pos / d4p : 0.0;
        double DA_neg = (Deff_neg > 0.0) ? Deff_neg / fabs(d4n) : 0.0;
        double DA = std::max(DA_pos, DA_neg);
        if (DA > TDA_max) {
            TDA_max = DA;
        }
        double DE = (energyU > 0.0) ? Cenergy / energyU : 0.0;
        double Dcomp_new = beta * DE + TDA_max;
        if (Dcomp_new > 1.0) Dcomp_new = 1.0;
        TDcomp = (Dcomp_new > TDcomp) ? Dcomp_new : TDcomp;
    }
    TlastLoadIndicator = newLoadIndicator;
    // --- Apply Damage to Backbone Strength Factors ---
    if (TDcomp != TDcomp_last) {
        TDcomp_last = TDcomp;
        TpreCapstrFactor = 1.0 - lambda_pre_peak * TDcomp;
        TpostCapstrFactor = 1.0 - lambda_post_peak * TDcomp;
        if (TpreCapstrFactor < 0.2) TpreCapstrFactor = 0.2;
        if (TpostCapstrFactor < 0.2) TpostCapstrFactor = 0.2;
    }
    // Smoothly degrade strengths without step-drops
    f1p = f1p_initial;
    f2p = f2p_initial;
    f3p = f3p_initial * TpreCapstrFactor;
    f4p = f4p_initial * TpostCapstrFactor;
    f1n = f1n_initial;
    f2n = f2n_initial;
    f3n = f3n_initial * TpreCapstrFactor;
    f4n = f4n_initial * TpostCapstrFactor;
    this->setEnvelope();
    // --- Determine Loading State ---
    if (TloadIndicator == 0) {
        TloadIndicator = (Ddisp < 0.0) ? 2 : 1;
    }
    // --- Calculate Response ---
    if (Tdisp >= CdMax) {
        Tfs = posBackForce(Tdisp);
        Tks = posBackTangent(Tdisp);
        TdMax = Tdisp;
        TloadIndicator = 1;
    }
    else if (Tdisp <= CdMin) {
        Tfs = negBackForce(Tdisp);
        Tks = negBackTangent(Tdisp);
        TdMin = Tdisp;
        TloadIndicator = 2;
    }
    else {
        if (Ddisp < 0.0) {
            negIncrement(Ddisp, TdMin, TdPu, Tfs, Tks, TloadIndicator, TDcomp);
        }
        else {
            posIncrement(Ddisp, TdMax, TdNu, Tfs, Tks, TloadIndicator, TDcomp);
        }
    }
    // --- Energy Calculation ---
    Tenergy = Cenergy + 0.5 * (Cfs + Tfs) * Ddisp;
    return 0;
}

// Backbone Force Functions
double QuickHys::posBackForce(double Tdisp) {
    if (Tdisp <= 0.0) return 0.0;
    if (Tdisp <= d1p) return E1p * Tdisp;
    if (Tdisp <= d2p) return f1p + E2p * (Tdisp - d1p);
    if (Tdisp <= d3p) return f2p + E3p * (Tdisp - d2p);
    if (Tdisp <= d4p || E4p > 0.0) return f3p + E4p * (Tdisp - d3p);
    return f4p;
}
double QuickHys::negBackForce(double Tdisp) {
    if (Tdisp >= 0.0) return 0.0;
    if (Tdisp >= d1n) return E1n * Tdisp;
    if (Tdisp >= d2n) return f1n + E2n * (Tdisp - d1n);
    if (Tdisp >= d3n) return f2n + E3n * (Tdisp - d2n);
    if (Tdisp >= d4n || E4n > 0.0) return f3n + E4n * (Tdisp - d3n);
    return f4n;
}

// Backbone Tangent Functions
double QuickHys::posBackTangent(double Tdisp) {
    if (Tdisp < 0.0) return 1e-9;
    if (Tdisp <= d1p) return E1p;
    if (Tdisp <= d2p) return E2p;
    if (Tdisp <= d3p) return E3p;
    if (Tdisp <= d4p || E4p > 0.0) return E4p;
    return 1e-9;
}
double QuickHys::negBackTangent(double Tdisp) {
    if (Tdisp > 0.0) return 1e-9;
    if (Tdisp >= d1n) return E1n;
    if (Tdisp >= d2n) return E2n;
    if (Tdisp >= d3n) return E3n;
    if (Tdisp >= d4n || E4n > 0.0) return E4n;
    return 1e-9;
}

// Increment functions with composite damage index
void QuickHys::posIncrement(double Ddisp, double& TdMax, double& TdNu, double& Tfs, double& Tks, int& TloadIndicator, double Dcomp) {
    double gamma_eff = (Dcomp >= 0.0) ? exp(-lambda_re * Dcomp) : 0.0;
    if (gamma_eff < 0.0) gamma_eff = 0.0;
    double Eup = E1p * ((1.0 - lambda_un * Dcomp) > 1e-9 ? (1.0 - lambda_un * Dcomp) : 1e-9);
    TdMin = CdMin;
    TloadIndicator = 1;
    double TfMax = posBackForce(TdMax);
    double pinchingX = gamma_eff * TdMax;
    double pinchingY = gamma_eff * TfMax;
    // Mechanical Bound: Prevent pinchingX from going behind the zero-crossing (TdNu)
    double tol = 1e-6 * d1p;
    if (pinchingX <= TdNu + tol) {
        pinchingX = TdNu + tol;
        pinchingY = std::max(pinchingY, 1e-6 * f1p);
    }
    double denom_pinch1 = pinchingX - TdNu;
    double Epinch1 = (denom_pinch1 > 1e-10) ? pinchingY / denom_pinch1 : 1e-9;
    double denom_pinch2 = TdMax - pinchingX;
    double Epinch2 = (denom_pinch2 > 1e-10) ? (TfMax - pinchingY) / denom_pinch2 : 1e-9;
    double D_rev = Tlast_reversal;
    double F_rev = (D_rev >= 0.0 ? posBackForce(D_rev) : negBackForce(D_rev));
    double Eup2 = unload_fact * Eup;
    if (Eup2 < 1e-9) Eup2 = 1e-9;
    double F_trans = trans_fact * F_rev;
    double denom_trans = F_trans - F_rev;
    double D_trans = D_rev + (fabs(denom_trans) > 1e-10 ? denom_trans / Eup : 0.0);
    double TdNu_calc = D_trans - (fabs(F_trans) > 1e-10 ? F_trans / Eup2 : 0.0);
    if (TdNu_calc > pinchingX) {
        double targetD = pinchingX;
        double targetF = pinchingY;
        double delta_D = targetD - D_trans;
        Eup2 = (fabs(delta_D) > 1e-10) ? (targetF - F_trans) / delta_D : 1e-9;
        if (Eup2 < 1e-9) Eup2 = 1e-9;
        TdNu_calc = targetD;
    }
    TdNu = TdNu_calc;
    if (Tdisp < D_trans) {
        Tks = Eup;
        Tfs = F_rev + Tks * (Tdisp - D_rev);
    }
    else if (Tdisp < TdNu) {
        Tks = Eup2;
        Tfs = F_trans + Tks * (Tdisp - D_trans);
    }
    else if (Tdisp < pinchingX) {
        Tks = Epinch1;
        Tfs = 0.0 + Tks * (Tdisp - TdNu);
    }
    else {
        Tks = Epinch2;
        Tfs = pinchingY + Tks * (Tdisp - pinchingX);
    }
}
void QuickHys::negIncrement(double Ddisp, double& TdMin, double& TdPu, double& Tfs, double& Tks, int& TloadIndicator, double Dcomp) {
    double gamma_eff = (Dcomp >= 0.0) ? exp(-lambda_re * Dcomp) : 0.0;
    if (gamma_eff < 0.0) gamma_eff = 0.0;
    double Eun = E1n * ((1.0 - lambda_un * Dcomp) > 1e-9 ? (1.0 - lambda_un * Dcomp) : 1e-9);
    TdMax = CdMax;
    TloadIndicator = 2;
    double TfMin = negBackForce(TdMin);
    double pinchingX = gamma_eff * TdMin;
    double pinchingY = gamma_eff * TfMin;
    // Mechanical Bound: Prevent pinchingX from going ahead of the zero-crossing (TdPu)
    double tol = 1e-6 * fabs(d1n);
    if (pinchingX >= TdPu - tol) {
        pinchingX = TdPu - tol;
        pinchingY = std::min(pinchingY, -1e-6 * fabs(f1n));
    }
    double denom_pinch1 = pinchingX - TdPu; // negative value
    double Epinch1 = (denom_pinch1 < -1e-10) ? pinchingY / denom_pinch1 : 1e-9;
    double denom_pinch2 = TdMin - pinchingX; // negative value
    double Epinch2 = (denom_pinch2 < -1e-10) ? (TfMin - pinchingY) / denom_pinch2 : 1e-9;
    double D_rev = Tlast_reversal;
    double F_rev = (D_rev >= 0.0 ? posBackForce(D_rev) : negBackForce(D_rev));
    double Eun2 = unload_fact * Eun;
    if (Eun2 < 1e-9) Eun2 = 1e-9;
    double F_trans = trans_fact * F_rev;
    double denom_trans = F_trans - F_rev;
    double D_trans = D_rev + (fabs(denom_trans) > 1e-10 ? denom_trans / Eun : 0.0);
    double TdPu_calc = D_trans - (fabs(F_trans) > 1e-10 ? F_trans / Eun2 : 0.0);
    if (TdPu_calc < pinchingX) {
        double targetD = pinchingX;
        double targetF = pinchingY;
        double delta_D = targetD - D_trans;
        Eun2 = (fabs(delta_D) > 1e-10) ? (targetF - F_trans) / delta_D : 1e-9;
        if (Eun2 < 1e-9) Eun2 = 1e-9;
        TdPu_calc = targetD;
    }
    TdPu = TdPu_calc;
    if (Tdisp > D_trans) {
        Tks = Eun;
        Tfs = F_rev + Tks * (Tdisp - D_rev);
    }
    else if (Tdisp > TdPu) {
        Tks = Eun2;
        Tfs = F_trans + Tks * (Tdisp - D_trans);
    }
    else if (Tdisp > pinchingX) {
        Tks = Epinch1;
        Tfs = 0.0 + Tks * (Tdisp - TdPu);
    }
    else {
        Tks = Epinch2;
        Tfs = pinchingY + Tks * (Tdisp - pinchingX);
    }
}

// Commit and revert methods
int QuickHys::commitState() {
    Cdisp = Tdisp;
    Cfs = Tfs;
    Cks = Tks;
    CdMax = (TdMax > CdMax) ? TdMax : CdMax;
    CdMin = (TdMin < CdMin) ? TdMin : CdMin;
    CdPu = TdPu;
    CdNu = TdNu;
    if (Tenergy > Cenergy) {
        Cenergy = Tenergy;
    }
    CloadIndicator = TloadIndicator;
    CcycleCount = TcycleCount;
    ClastLoadIndicator = TlastLoadIndicator;
    Clast_half_cycle_amplitude = Tlast_half_cycle_amplitude;
    Clast_reversal = Tlast_reversal;
    Cprev_reversal = Tprev_reversal;
    Cdelta_rev = Tdelta_rev;
    CDA_max = TDA_max;
    CDcomp = TDcomp;
    CDcomp_last = TDcomp_last;
    CpreCapstrFactor = TpreCapstrFactor;
    CpostCapstrFactor = TpostCapstrFactor;
    return 0;
}
int QuickHys::revertToLastCommit() {
    Tdisp = Cdisp;
    Tfs = Cfs;
    Tks = Cks;
    TdMax = CdMax;
    TdMin = CdMin;
    TdPu = CdPu;
    TdNu = CdNu;
    Tenergy = Cenergy;
    TloadIndicator = CloadIndicator;
    TcycleCount = CcycleCount;
    TlastLoadIndicator = ClastLoadIndicator;
    Tlast_half_cycle_amplitude = Clast_half_cycle_amplitude;
    Tlast_reversal = Clast_reversal;
    Tprev_reversal = Cprev_reversal;
    Tdelta_rev = Cdelta_rev;
    TDA_max = CDA_max;
    TDcomp = CDcomp;
    TDcomp_last = CDcomp_last;
    TpreCapstrFactor = CpreCapstrFactor;
    TpostCapstrFactor = CpostCapstrFactor;
    f1p = f1p_initial;
    f2p = f2p_initial;
    f3p = f3p_initial * TpreCapstrFactor;
    f4p = f4p_initial * TpostCapstrFactor;
    f1n = f1n_initial;
    f2n = f2n_initial;
    f3n = f3n_initial * TpreCapstrFactor;
    f4n = f4n_initial * TpostCapstrFactor;
    this->setEnvelope();
    return 0;
}
int QuickHys::revertToStart() {
    Cdisp = 0.0;
    Cfs = 0.0;
    Cks = f1p_initial / d1p;
    CdMax = 0.0;
    CdMin = 0.0;
    Cenergy = 0.0;
    CdPu = 0.0;
    CdNu = 0.0;
    CloadIndicator = 0;
    CcycleCount = 0;
    ClastLoadIndicator = 0;
    Clast_half_cycle_amplitude = 0.0;
    Clast_reversal = 0.0;
    Cprev_reversal = 0.0;
    Cdelta_rev = 0.0;
    CDA_max = 0.0;
    CDcomp = 0.0;
    CDcomp_last = -1.0;
    CpreCapstrFactor = 1.0;
    CpostCapstrFactor = 1.0;
    f1p = f1p_initial;
    f2p = f2p_initial;
    f3p = f3p_initial;
    f4p = f4p_initial;
    f1n = f1n_initial;
    f2n = f2n_initial;
    f3n = f3n_initial;
    f4n = f4n_initial;
    this->setEnvelope();
    this->revertToLastCommit();
    return 0;
}

// Getters
double QuickHys::getStress() { return Tfs; }
double QuickHys::getTangent() { return Tks; }
double QuickHys::getStrain() { return Tdisp; }
double QuickHys::getInitialTangent() { return f1p_initial / d1p; }

// Copy method
UniaxialMaterial* QuickHys::getCopy() {
    return new QuickHys(this->getTag(), f1p_initial, d1p, f2p_initial, d2p, f3p_initial, d3p, f4p_initial, d4p,
        f1n_initial, d1n, f2n_initial, d2n, f3n_initial, d3n, f4n_initial, d4n,
        beta, lambda_pre_peak, lambda_post_peak, lambda_re, lambda_un,
        unload_fact, trans_fact);
}

// Print method
void QuickHys::Print(OPS_Stream& s, int flag) {
    s << "QuickHys: tag=" << this->getTag() << "\n";
}

// Serialization methods (updated - removed unused du_pos_minus_dy_pos / du_neg_minus_dy_neg)
int QuickHys::sendSelf(int commitTag, Channel& theChannel) {
    Vector data(53); // Reduced from 55
    data(0) = this->getTag();
    data(1) = f1p_initial;
    data(2) = d1p;
    data(3) = f2p_initial;
    data(4) = d2p;
    data(5) = f3p_initial;
    data(6) = d3p;
    data(7) = f4p_initial;
    data(8) = d4p;
    data(9) = f1n_initial;
    data(10) = d1n;
    data(11) = f2n_initial;
    data(12) = d2n;
    data(13) = f3n_initial;
    data(14) = d3n;
    data(15) = f4n_initial;
    data(16) = d4n;
    data(17) = lambda_post_peak;
    data(18) = lambda_re;
    data(19) = lambda_un;
    data(20) = Cdisp;
    data(21) = Cfs;
    data(22) = Cks;
    data(23) = CdMax;
    data(24) = CdMin;
    data(25) = Cenergy;
    data(26) = CdPu;
    data(27) = CdNu;
    data(28) = static_cast<double>(CloadIndicator);
    data(29) = static_cast<double>(CcycleCount);
    data(30) = f1p;
    data(31) = f2p;
    data(32) = f3p;
    data(33) = f4p;
    data(34) = f1n;
    data(35) = f2n;
    data(36) = f3n;
    data(37) = f4n;
    data(38) = static_cast<double>(ClastLoadIndicator);
    data(39) = Clast_half_cycle_amplitude;
    data(40) = beta;
    data(41) = CDA_max;
    data(42) = CDcomp;
    data(43) = lambda_pre_peak;
    data(44) = unload_fact;
    data(45) = trans_fact;
    data(46) = Clast_reversal;
    data(47) = Cprev_reversal;
    data(48) = CpreCapstrFactor;
    data(49) = CpostCapstrFactor;
    data(50) = CDcomp_last;
    data(51) = Cdelta_rev;
    data(52) = energyU;
    if (theChannel.sendVector(this->getDbTag(), commitTag, data) < 0) {
        opserr << "QuickHys::sendSelf - failed to send data.\n";
        return -1;
    }
    return 0;
}
int QuickHys::recvSelf(int commitTag, Channel& theChannel, FEM_ObjectBroker& theBroker) {
    Vector data(53); // Reduced from 55
    if (theChannel.recvVector(this->getDbTag(), commitTag, data) < 0) {
        opserr << "QuickHys::recvSelf - failed to receive data.\n";
        return -1;
    }
    this->setTag(static_cast<int>(data(0)));
    f1p_initial = data(1);
    d1p = data(2);
    f2p_initial = data(3);
    d2p = data(4);
    f3p_initial = data(5);
    d3p = data(6);
    f4p_initial = data(7);
    d4p = data(8);
    f1n_initial = data(9);
    d1n = data(10);
    f2n_initial = data(11);
    d2n = data(12);
    f3n_initial = data(13);
    d3n = data(14);
    f4n_initial = data(15);
    d4n = data(16);
    lambda_post_peak = data(17);
    lambda_re = data(18);
    lambda_un = data(19);
    Cdisp = data(20);
    Cfs = data(21);
    Cks = data(22);
    CdMax = data(23);
    CdMin = data(24);
    Cenergy = data(25);
    CdPu = data(26);
    CdNu = data(27);
    CloadIndicator = static_cast<int>(data(28));
    CcycleCount = static_cast<int>(data(29));
    f1p = data(30);
    f2p = data(31);
    f3p = data(32);
    f4p = data(33);
    f1n = data(34);
    f2n = data(35);
    f3n = data(36);
    f4n = data(37);
    ClastLoadIndicator = static_cast<int>(data(38));
    Clast_half_cycle_amplitude = data(39);
    beta = data(40);
    CDA_max = data(41);
    CDcomp = data(42);
    lambda_pre_peak = data(43);
    unload_fact = data(44);
    trans_fact = data(45);
    Clast_reversal = data(46);
    Cprev_reversal = data(47);
    CpreCapstrFactor = data(48);
    CpostCapstrFactor = data(49);
    CDcomp_last = data(50);
    Cdelta_rev = data(51);
    energyU = data(52);
    this->setEnvelope();
    revertToLastCommit();
    return 0;
}