#ifndef QUICKHYS_H
#define QUICKHYS_H
#include <UniaxialMaterial.h>
#include <OPS_Stream.h>
#include <Channel.h>
#include <FEM_ObjectBroker.h>
class QuickHys : public UniaxialMaterial {
public:
    // Default constructor for FEM_ObjectBroker
    QuickHys();
    // Updated constructor with all parameters including unload_fact and trans_fact
    QuickHys(int tag, double f1p, double d1p, double f2p, double d2p, double f3p, double d3p, double f4p, double d4p,
        double f1n, double d1n, double f2n, double d2n, double f3n, double d3n, double f4n, double d4n,
        double beta, double lambda_pre_peak, double lambda_post_peak, double lambda_re, double lambda_un,
        double unload_fact, double trans_fact);
    // Destructor
    ~QuickHys();
    // OpenSees required methods
    int setTrialStrain(double strain, double strainRate = 0.0) override;
    double getStress() override;
    double getTangent() override;
    double getStrain() override;
    double getInitialTangent() override;
    int commitState() override;
    int revertToLastCommit() override;
    int revertToStart() override;
    // Copy method
    UniaxialMaterial* getCopy() override;
    // Print method
    void Print(OPS_Stream& s, int flag = 0) override;
    // Serialization methods
    int sendSelf(int commitTag, Channel& theChannel) override;
    int recvSelf(int commitTag, Channel& theChannel, FEM_ObjectBroker& theBroker) override;
private:
    double energyU; // Total energy determined by the backbone curve
    // Material parameters
    double f1p, d1p, f2p, d2p, f3p, d3p, f4p, d4p; // Positive backbone points
    double f1n, d1n, f2n, d2n, f3n, d3n, f4n, d4n; // Negative backbone points
    double beta; // Formerly wE, weight for energy damage
    double lambda_pre_peak;
    double lambda_post_peak; // Formerly beta_post_cap
    double lambda_re; // Decay rate constant for pinching evolution
    double lambda_un; // Amplitude sensitivity parameter for pinching degradation
    double unload_fact; // Factor for bi-linear unloading stiffness
    double trans_fact; // Factor for transition point in bi-linear unloading
    // Initial strengths
    double f1p_initial, f2p_initial, f3p_initial, f4p_initial; // Initial positive strengths
    double f1n_initial, f2n_initial, f3n_initial, f4n_initial; // Initial negative strengths
    // Precomputed envelope slopes
    double E1p, E2p, E3p, E4p; // Positive slopes
    double E1n, E2n, E3n, E4n; // Negative slopes
    // Precomputed differences
    double du_pos_minus_dy_pos; // d4p - d1p
    double du_neg_minus_dy_neg; // d1n - d4n
    // Cached damage factors
    double CpreCapstrFactor, CpostCapstrFactor;
    double TpreCapstrFactor, TpostCapstrFactor;
    // Committed state variables
    double CdMax, CdMin; // Committed max/min displacements
    double Cenergy; // Committed cumulative hysteretic energy
    double CdPu, CdNu; // Committed positive/negative unloading displacements
    double Cdisp, Cfs, Cks; // Committed displacement, force, stiffness
    int CloadIndicator; // Committed load direction indicator
    int CcycleCount; // Number of loading cycles
    int ClastLoadIndicator; // Last load indicator for cycle detection
    double Cdelta_rev; // Deformation amplitude of the last half-cycle
    double Clast_half_cycle_amplitude; // Last computed half-cycle amplitude
    double Clast_reversal; // Last reversal point
    double Cprev_reversal; // Previous reversal point
    double CDA_max; // Maximum amplitude-driven damage
    double CDcomp; // Current damage index
    double CDcomp_last; // Last committed Dcomp for change detection
    // Trial state variables
    double TdMax, TdMin; // Trial max/min displacements
    double Tenergy; // Trial cumulative hysteretic energy
    double TdPu, TdNu; // Trial positive/negative unloading displacements
    double Tdisp, Tfs, Tks; // Trial displacement, force, stiffness
    int TloadIndicator; // Trial load direction indicator
    int TcycleCount; // Trial number of loading cycles
    int TlastLoadIndicator; // Trial last load indicator for cycle detection
    double Tdelta_rev; // Trial deformation amplitude of the last half-cycle
    double Tlast_half_cycle_amplitude; // Trial last computed half-cycle amplitude
    double Tlast_reversal; // Trial last reversal point
    double Tprev_reversal; // Trial previous reversal point
    double TDA_max; // Trial maximum amplitude-driven damage
    double TDcomp; // Trial current damage index
    double TDcomp_last; // Trial last committed Dcomp for change detection
    // Backbone functions
    double posBackForce(double disp);
    double negBackForce(double disp);
    double posBackTangent(double disp);
    double negBackTangent(double disp);
    // Incremental behavior
    void posIncrement(double Ddisp, double& TdMax, double& TdNu, double& Tfs, double& Tks, int& TloadIndicator, double Dcomp);
    void negIncrement(double Ddisp, double& TdMin, double& TdPu, double& Tfs, double& Tks, int& TloadIndicator, double Dcomp);
    // Precompute envelope
    void setEnvelope();
};
#endif